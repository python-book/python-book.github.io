x = 10
y = 3

sum_ = x + y
print("#", sum_)
# 13

difference = x - y
print("#", difference)
# 7

product = x * y
print("#", product)
# 30

quotient = x / y
print("#", quotient)
# 3.3333333333333335

exponential = x ** y
print("#", exponential)
# 1000

euclidean_quotient = x // y
print("#", euclidean_quotient)
# 3

remainder = x % y
print("#", remainder)
# 1
