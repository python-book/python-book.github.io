x = 16
y = 3

x += y
print("#", x)
# 19

x -= y
print("#", x)
# 16

x *= y
print("#", x)
# 48

x /= y
print("#", x)
# 16.0

x //= y
print("#", x)
# 5.0

x %= y
print("#", x)
# 2.0

x **= y
print("#", x)
# 8.0
