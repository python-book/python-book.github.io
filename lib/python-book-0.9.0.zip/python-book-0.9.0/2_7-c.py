x = input("enter 12:")
y = 3
z = int(x)
print(f"# {z * y=}")
# z * y=36
