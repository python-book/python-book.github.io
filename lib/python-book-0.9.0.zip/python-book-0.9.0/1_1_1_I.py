PI = 3.14
r = 10
circumference = 2 * PI * r
print(circumference)
