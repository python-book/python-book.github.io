x = -1
if x < 0:
    print(f"# {x} is negative.")
    print(f"# cannot calculate squareroot of {x}.")
else:
    print(f"# {x} is not negative.")
    print(f"# can calculate squareroot of {x}")
# -1 is negative.
# cannot calculate squareroot of -1.

y = 0
if y:
    print(f"# {y} is not zero")
    print(f"# {y} can be used as denominator")
else:
    print(f"# {y} is Falsy")
    print(f"# {y} cannot be used as denominator")
# 0 is Falsy
# 0 cannot be used as denominator
