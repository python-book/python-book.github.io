total = 1 +\
    2 +\
    3
print("#",
      total
      )
multi_line_text = """\
String in multi-line-text
can span across multiple lines,
it can have quotation marks like "
even include '''
"""
print(multi_line_text)
print("Hello "
      "World!")
