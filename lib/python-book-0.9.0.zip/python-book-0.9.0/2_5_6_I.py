string_1 = "abcde\"\t\"fghij\nklmno\' \'pqrst\n"
print("'''string_1:\n" + string_1 + "\n'''")
'''string_1: 
abcde"	"fghij
klmno' 'pqrst

'''

book_filename = "\120\x79\x74\x68\x6f\x6e\u7a0b\u5e8f\u8bbe\u8ba1"
print("# bookname:", book_filename)
# bookname: Python程序设计
