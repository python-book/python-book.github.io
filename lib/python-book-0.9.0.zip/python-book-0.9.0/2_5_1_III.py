string = "Hello World!"

print("#", string[:5])
# Hello

print("#", string[3:-4])
# lo Wo

print("#", string[-9:8])
# lo Wo

print("#", string[-6:])
# World!
