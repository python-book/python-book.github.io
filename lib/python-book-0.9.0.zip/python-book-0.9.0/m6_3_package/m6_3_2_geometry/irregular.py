"""Part of demo of package structure, calculate circle area and circumference.

Functions:
    area(): not yet implemented
    perimeter(): not yet implemented

Note:
    intentionally left unfinished, used to demo import all can
    omit some packages.
"""
"""save this as m6_3_package/m6_3_2_geometry/irregular.py"""

def area() -> None:
    """irregular shape's area
    Not yet implemented
    """
    pass

def perimeter() -> None:
    """irregular shape's perimeter
    Not yet implemented
    """
    pass
