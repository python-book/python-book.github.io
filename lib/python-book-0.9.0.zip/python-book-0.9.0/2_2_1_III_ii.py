x = 10
y = x
print("#", x, y)
# 10 10

y = x = x / 2
print("#", x, y)
# 5.0 5.0
