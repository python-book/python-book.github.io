string = "AaBbCcDdEeFfGg"

print("#", string[::2])
# ABCDEFG

print("#", string[-13:12:4])
# ace

print("#", string[2::7])
# Be

print("#", string[::-2])
# gfedcba

print("#", string[-1:1:-2])
# gfedcb

print("#", string[-2::-2])
# GFEDCBA

print("#", string[1:-1:-1])
#
