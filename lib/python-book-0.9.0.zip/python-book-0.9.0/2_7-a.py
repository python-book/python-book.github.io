x = 1
print(f"# {type(x)=}")
# type(x)=<class 'int'>

x = "string"
print(f"# {type(x)=}")
# type(x)=<class 'str'>
