list_example=[1,2,"3","four",5.0, 1]
for item in list_example:
    print (f"# there is a: {item}")
# there is a: 1
# there is a: 2
# there is a: 3
# there is a: four
# there is a: 5.0
# there is a: 1
