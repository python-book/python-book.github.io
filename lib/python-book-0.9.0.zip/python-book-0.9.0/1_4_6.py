print("#","This is the output.") #This is a comment
# This is the output.
