x = 5
print("#", x)
# 5

x = x * 2
print("#", x)
# 10
