odd_squares = {x * x for x in range(-5, 6) if x % 2}
print(f"# {odd_squares=}")
# odd_squares={25, 9, 1}
