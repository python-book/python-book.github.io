set_example = {1, 2, "3", "four", 5.0, 1}
print(f"# set deduplicates to: {set_example}")
# set deduplicates to: {1, 2, 5.0, '3', 'four'}
