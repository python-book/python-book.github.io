n = 5
factorial = 1
i = 0
while (i := i + 1) <= n:
    factorial *= i

print(f"# factorial of {n} is {factorial}")
# factorial of 5 is 120
