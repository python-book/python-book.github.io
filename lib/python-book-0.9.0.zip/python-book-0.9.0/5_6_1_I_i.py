dict_example = {"brand":"VW", "model":"Jetta", "milage":0, "milage":200000}
print (f"# dictionary: {dict_example}")
# dictionary: {'brand': 'VW', 'model': 'Jetta', 'milage': 200000}
