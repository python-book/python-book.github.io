x = input("enter 12:")
y = 3
print(f"# {x * y=}")
# x * y='121212'
