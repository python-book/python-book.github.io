x = 10
print("#", x, "is of type", type(x))
# 10 is of type <class 'int'>

x = x / 2
print("#", x, "is of type", type(x))
# 5.0 is of type <class 'float'>
