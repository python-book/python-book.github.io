x = 1; y = 2; z = 3; print(x, y, z)
if x < y : print(x,y)
for v in (x, y, z): w = v * 2; print(w)
