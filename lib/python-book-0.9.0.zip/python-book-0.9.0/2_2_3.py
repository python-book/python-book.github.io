radius = 3
print("# radius is defined:", 'radius' in dir())
# radius is defined: True

del radius
print("# radius is defined:", 'radius' in dir())
# radius is defined: False
