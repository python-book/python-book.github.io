x = -1
if x < 0:
    print(f"# {x} is negative.")
    print(f"# cannot calculate squareroot of {x}.")
# -1 is negative.
# cannot calculate squareroot of -1.

y = 0
if y:
    print(f"# {y} is not zero")
    print(f"# {y} can be used as denominator")

z = 1
print(f"# {z} is another number.")
# -1 is another number.
