list_str = ['abc', 'bca', 'cab', 'acb']
print(f"# {list_str=}")
# list_str=['abc', 'bca', 'cab', 'acb']

list_str_reversed = list(reversed(list_str))
print(f"# {list_str_reversed=}")
# list_str_reversed=['acb', 'cab', 'bca', 'abc']
