string_1 = 'Python程序设计\n'
s0 = string_1[0]
print(f"# {s0=}, {ord(s0)=}")
# s0='P', ord(s0)=80

s6 = string_1[6]
print(f"# {s6=}, {ord(s6)=} or as Hex: {ord(s6)=:x}")
# s6='程', ord(s6)=31243 or as Hex: ord(s6)=7a0b

s_1 = string_1[-1]
print(f"# {s_1=}, {ord(s_1)} or as Oct: {ord(s_1)=:03o}")
# s_1='\n', 10 or as Oct: ord(s_1)=012
