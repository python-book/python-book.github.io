a = 1
print(f"# use {{a * 3=:08d}} to debug: {a * 3=:08d}")
# use {a * 3=:08d} to debug: a * 3=00000003
