x = 10
y = 3

sum_ = x + y
print("# x+y =", sum_)
# x+y = 13

difference = x - y
print("# x-y =", difference)
# x-y = 7

product = x * y
print("# x*= =", product)
# x*= = 30

quotient = x / y
print("# x/y =", quotient)
# x/y = 3.3333333333333335

exponential = x ** y
print("# x**y =", exponential)
# x**y = 1000

euclidean_quotient = x // y
print("# x//y =", euclidean_quotient)
# x//y = 3

remainder = x % y
print("# x%y =", remainder)
# x%y = 1
