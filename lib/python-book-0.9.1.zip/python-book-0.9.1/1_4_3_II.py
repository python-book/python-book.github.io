def func_indent(additional_text):
    if True:
        text = "Indentation is vital in Python!"
        print(text, additional_text)
    return "function executed"


print(func_indent("That's right!"))
