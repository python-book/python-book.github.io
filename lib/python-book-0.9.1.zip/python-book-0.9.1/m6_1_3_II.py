"""
Main script demonstrating importing a module.
"""
"""save this as m6_1_3_II.py"""
import m6_1_circle

print(f"# module set PI to: {m6_1_circle.PI}")
# module set PI to: 3.14159265

radius = 3

print(f"# area of {radius=} is {m6_1_circle.area(radius)}")
# area of radius=3 is 28.27433385

print(f"# circumference of {radius=} is {m6_1_circle.circumference(radius)}")
# circumference of radius=3 is 18.849555900000002
