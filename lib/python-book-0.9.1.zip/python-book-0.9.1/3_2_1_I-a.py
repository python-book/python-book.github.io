x = -1
if x < 0: print(f"# {x} is negative.")
# -1 is negative

y = 0
if y:
    print(f"# {y} is Truthy.")
