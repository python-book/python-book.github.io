def pi() -> float:
    PI = 3.14159
    return PI
