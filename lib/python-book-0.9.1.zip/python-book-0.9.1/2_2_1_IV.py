x = 10

x = (y := x) / 2
print("#", x, y)
# 5.0 10
