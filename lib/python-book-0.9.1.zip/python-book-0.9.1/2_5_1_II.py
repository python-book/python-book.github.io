string = "Hello World!"
character1 = string[0]
character2 = string[-6]
character3 = string[-1]
print("#", character1, character2, character3)
# H W !
