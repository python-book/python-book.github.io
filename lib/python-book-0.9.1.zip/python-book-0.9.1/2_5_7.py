unit_price = 25.92
quantity = 6
fstring = f"price: ${unit_price}/kg, quantity: {quantity}kg, \
    total: ${quantity * unit_price}"
quantity = 30
print("#", fstring)
# price: $25.92/kg, quantity: 6kg,  total: $155.52
