letters = "ABCDE"
for letter in letters:
    ascii_code = ord(letter)
    print(f"# {letter} is the #{ascii_code - 64:2d} letter in the alphabet.")
# A is the # 1 letter in the alphabet.
# B is the # 2 letter in the alphabet.
# C is the # 3 letter in the alphabet.
# D is the # 4 letter in the alphabet.
# E is the # 5 letter in the alphabet.
