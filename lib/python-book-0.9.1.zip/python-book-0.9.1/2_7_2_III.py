float_1 = 3.5
print(f"# {float_1} can be expressed as {float_1.as_integer_ratio()}")
# 3.5 can be expressed as (7, 2)

float_2 = 3.2
print(f"# {float_2} can be expressed as {float_2.as_integer_ratio()}")
# 3.2 can be expressed as (3602879701896397, 1125899906842624)
