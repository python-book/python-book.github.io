user_input = input("# Please enter anything:")
# Please enter anything:a string

print(f"# {type(user_input)=}, {user_input=}")
# type(user_input)=<class 'str'>, user_input='a string'
