PI = 3.14
radius = 2
print("# area of circle 2:", PI * (radius ** 2))
# area of circle 2: 12.56

radius = 3
print("# volume of sphere 3:", PI * (radius ** 3) * 4 / 3)
# volume of sphere 3: 113.04
