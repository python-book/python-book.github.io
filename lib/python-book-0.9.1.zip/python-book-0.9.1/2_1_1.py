print("#", "this is a string literal") 
# this is a string literal
 
print("#", 3.14159) 
# 3.14159
 
print("#", True) 
# True
