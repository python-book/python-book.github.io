string_example = "AbCdEf"
print(f"# convert string to list: {list(string_example)}")
# convert string to list: ['A', 'b', 'C', 'd', 'E', 'f']

range_example = range(0, 6)
print(f"# convert range to list: {list(range_example)}")
# convert range to list: [0, 1, 2, 3, 4, 5]
