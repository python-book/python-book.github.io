str_1 = "ABCD"
list_1 = [1, '2.0', (3.0 + 4j)]

char_1, char_2, char_3, char_4 = str_1
print(f"# {char_1=}, {char_2=}, {char_3=}, {char_4=}")
# char_1='A', char_2='B', char_3='C', char_4='D'

int_1, str_2, comp_3 = list_1
print(f"# {int_1=}, {str_2=}, {comp_3=}")
# int_1=1, str_2='2.0', comp_3=3+4j
