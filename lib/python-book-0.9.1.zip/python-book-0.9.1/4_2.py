def f(x):
    PI = 3.14159
    circumference = 2 * PI * x
    return circumference
