number = 1
print(number)
